from systemtools.file import *
from systemtools.location import *
from systemtools.basics import *






path = sortedGlob("/home/hayj/Downloads/*.bin")[0]

bin2txtFile(path)


