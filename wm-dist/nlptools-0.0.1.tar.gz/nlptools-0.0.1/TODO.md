
# Annotation

Faire une annotation des différents news selon leur qualité en affichant 100 examples pris au hasard et en appliquand sentencesToParagraph
Un chiffre entre 0 et 1
Puis e selectionner que les meilleurs

Ou donner un chiffre d'évidence entre 0 et 1
Et un chiffre de qualité de news

# Hard post-tokenization processing


le modèle d'authorship attribution ne doit pas reconnaitre pas les "..." en fin de text par exemple, ou les suites étranges comme - @


TODO faire une tokenization et post processing et voir ce qui change avant et apres le post-process, sur le vrai dataset


# News validité

TODO OOOOOOOOOOOOOO OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO Eliminer les docs qui ont une moyenne longueur phrase trop courte pour eviter les bruits

Voir comment faire un modèle robuste à la taille des articles  










# Plus tard Les poemes sont mal tokenisés

If you find a way inside I'll show you how I feel
When I grow up I want a treehouse with no stairs
I'll have a dog named Syd and a rabbit I'll call Hare
And if you feel like you might have some love to share
You can just fly on up you know that I'll be there
You don't understand how
Much I want you now but
If you find a way inside I'll show you how I feel

# Plus tard Eliminer les truc trop évident genre

	(CNN) All over the world, proud parents drop the

qui donne tokenisé

	( CNN ) All over the world , p

# Plus tard Trouver une solution pour eliminer les documents du type

	Our Terms of Service and Privacy Policy have changed.
	By continuing to use this site, you are agreeing to the new Privacy Policy and Terms of Service.

# Plus tard

TODO handle non utf-8 texts (ascii, bytes...) in preprocess
remplacer les urls par le domaine ?

check si les hashtag et @ sont bien tokenisés, et si les urls sont bien gérées

garder les @ et #

garder les emails

faire des break de sentence lors des retours lignes, remplacer les retour ligne par des points?
ou trouver un meilleur tokeniser
ou juste faire text = re.sub("\s*\n\s*([A-Z])", ".\n\g1", text)

probleme dans "impression is" pour le html pas supprimé
dans "IMG style" pareil
dans "Check this formula" pour l'email réduit --> ignored

Faire le stopword removal

# Trash

TODO OOO use the urlparser to replace url before tokenize





Attention bien verif en faisant un un check de quel sont les lignes suppr en passant sur la bdd
condition de longueur en debt de boucle
aussi remplacer tous les non [a-zA-Z] par " . " pour qu'il compte comme un mot
